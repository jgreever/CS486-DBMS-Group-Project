Team Name: eb642e46-2d7e-4105-8e22-78aed117f57a
Team Members: Justin Greever, Alissa Friel, Sam Khodakovskiy, Vinh Duong, Chris Lu

Project 3: CS-486

How to navigate the files:

1. All answers to our 20 questions are in the folder "Query Text Files". The files are named the same as the questions.
   Example: How are you? -> How_are_you.txt

2. All data from the database has been output into TSV files in the directory "Excel Spreadsheets of Table Data" and each
   file is named after the table the data came from.

3. The file "create_table_statements.sql" is the resulting statements to create our tables and their columns.

4. The file "populate_database_with_data_in_python.py" is the python3 code that was used to import the data from the original
   csv files and import them into the database. It has all the details on the use as well as comments describing each section.

5. The file "Project_3_Queries.txt" is the file that contains our 20 questions and the SQL statements needed to generate answers.

6. The file "Schema_Diagram_dbms.pdf" is our schema diagram with changes made along the way from the first submission.
